const formCadastro = document.getElementById("formCadastro");
if (formCadastro) {
  formCadastro.addEventListener("submit", function (e) {
    e.preventDefault();
    localStorage.setItem("usuario", JSON.stringify({
      nome: document.getElementById("nome").value,
      email: document.getElementById("email").value
    }));
    window.location.href = "registro.html";
  });
}

const formRegistro = document.getElementById("formRegistro");
const tabelaRegistros = document.getElementById("tabelaRegistros")?.querySelector("tbody");

function adicionarNaTabela(descricao, valor, tipo) {
  const linha = document.createElement("tr");
  linha.innerHTML = `
    <td>${descricao}</td>
    <td>${valor.toFixed(2)}</td>
    <td>${tipo === "gasto" ? "Gasto" : "Poupança"}</td>
  `;
  tabelaRegistros.appendChild(linha);
}

function carregarRegistros() {
  const gastos = JSON.parse(localStorage.getItem("gastos")) || [];
  const poupancas = JSON.parse(localStorage.getItem("poupancas")) || [];

  if (tabelaRegistros) {
    tabelaRegistros.innerHTML = "";
    gastos.forEach(item => adicionarNaTabela(item.descricao, item.valor, "gasto"));
    poupancas.forEach(item => adicionarNaTabela(item.descricao, item.valor, "poupanca"));
  }
}

if (formRegistro) {
  formRegistro.addEventListener("submit", function (e) {
    e.preventDefault();

    const descricao = document.getElementById("descricao").value;
    const valor = parseFloat(document.getElementById("valor").value);
    const tipo = document.getElementById("tipo").value;

    if (!descricao || isNaN(valor) || !tipo) return;

    const registro = { descricao, valor };

    if (tipo === "gasto") {
      const gastos = JSON.parse(localStorage.getItem("gastos")) || [];
      gastos.push(registro);
      localStorage.setItem("gastos", JSON.stringify(gastos));
    } else if (tipo === "poupanca") {
      const poupancas = JSON.parse(localStorage.getItem("poupancas")) || [];
      poupancas.push(registro);
      localStorage.setItem("poupancas", JSON.stringify(poupancas));
    }

    adicionarNaTabela(descricao, valor, tipo);

    document.getElementById("descricao").value = "";
    document.getElementById("valor").value = "";
    document.getElementById("tipo").value = "";
  });

  carregarRegistros();
}

function carregarGrafico() {
  const canvas = document.getElementById('graficoFinanceiro');
  if (!canvas) return;

  const gastos = JSON.parse(localStorage.getItem("gastos")) || [];
  const poupancas = JSON.parse(localStorage.getItem("poupancas")) || [];

  
  const todosRegistros = [
    ...gastos.map(g => ({ ...g, tipo: 'Gasto' })),
    ...poupancas.map(p => ({ ...p, tipo: 'Poupança' }))
  ];

  const labels = todosRegistros.map(r => r.descricao);
  const dados = todosRegistros.map(r => r.valor);
  const cores = todosRegistros.map(r => r.tipo === 'Gasto' ? '#e74c3c' : '#2ecc71');
  const bordas = todosRegistros.map(cor => cor === '#e74c3c' ? '#c0392b' : '#27ae60');

  new Chart(canvas, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Valor (R$)',
        data: dados,
        backgroundColor: cores,
        borderColor: bordas,
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            color: '#ffffff'
          },
          grid: {
            color: 'rgba(255,255,255,0.1)'
          }
        },
        x: {
          ticks: {
            color: '#ffffff'
          },
          grid: {
            color: 'rgba(255,255,255,0.05)'
          }
        }
      },
      plugins: {
        legend: {
          labels: {
            color: '#ffffff'
          }
        },
        title: {
          display: true,
          text: 'Gastos e Poupanças Individuais',
          color: '#ffffff',
          font: {
            size: 18
          }
        },
        tooltip: {
          callbacks: {
            label: function (context) {
              return `R$ ${context.raw.toFixed(2)}`;
            }
          }
        }
      }
    }
  });
}

document.addEventListener("DOMContentLoaded", carregarGrafico);
function carregarTabelaGrafico() {
    const tabela = document.getElementById("tabelaGrafico")?.querySelector("tbody");
    if (!tabela) return;
  
    const gastos = JSON.parse(localStorage.getItem("gastos")) || [];
    const poupancas = JSON.parse(localStorage.getItem("poupancas")) || [];
  
    tabela.innerHTML = "";
  
    gastos.forEach(item => {
      const linha = document.createElement("tr");
      linha.innerHTML = `
        <td>${item.descricao}</td>
        <td>${item.valor.toFixed(2)}</td>
        <td>Gasto</td>
      `;
      tabela.appendChild(linha);
    });
  
    poupancas.forEach(item => {
      const linha = document.createElement("tr");
      linha.innerHTML = `
        <td>${item.descricao}</td>
        <td>${item.valor.toFixed(2)}</td>
        <td>Poupança</td>
      `;
      tabela.appendChild(linha);
    });
  }
  
  document.addEventListener("DOMContentLoaded", () => {
    carregarGrafico();
    carregarTabelaGrafico();
  });
  