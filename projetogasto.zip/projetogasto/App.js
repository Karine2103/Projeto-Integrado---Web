import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ImageBackground,
  Image,
  Dimensions
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const bgImage = { uri: 'https://i.pinimg.com/236x/66/bb/b3/66bbb3d0aa0a6112a0e7a46951f5ae1d.jpg' };
const anotacaoImage = { uri: 'https://i.pinimg.com/736x/16/f7/4b/16f74bc172de438871e7577a1c7653d4.jpg' };
const logoImage = require('./assets/logo.png');
const screenWidth = Dimensions.get('window').width;

function SplashScreen({ navigation }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.replace('Login');
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <ImageBackground source={bgImage} style={styles.background}>
      <View style={styles.overlay} />
      <Image source={logoImage} style={styles.logoImage} resizeMode="contain" />
    </ImageBackground>
  );
}

function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  function handleLogin() {
    navigation.replace('NovaAnotacao');
  }

  return (
    <ImageBackground source={bgImage} style={styles.background}>
      <View style={styles.overlay} />

      <Image source={logoImage} style={styles.logoImageSmall} resizeMode="contain" />
      <View style={styles.loginBox}>
        <Text style={styles.loginTitle}>Login</Text>

        <TextInput
          placeholder="Email"
          placeholderTextColor="#ccc"
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
        />
        <TextInput
          placeholder="Senha"
          placeholderTextColor="#ccc"
          style={styles.input}
          value={senha}
          onChangeText={setSenha}
          secureTextEntry
        />
        <TouchableOpacity style={styles.btn} onPress={handleLogin}>
          <Text style={styles.btnText}>Entrar</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}

function NovaAnotacaoScreen() {
  const [valor, setValor] = useState('');
  const [tipo, setTipo] = useState(null);
  const [data, setData] = useState('');

  return (
    <ImageBackground source={anotacaoImage} style={styles.background}>
      <View style={styles.novaAnotacaoContent}>
        <Image source={logoImage} style={styles.logoImageSmall} resizeMode="contain" />
        <Text style={styles.novaAnotacaoTitulo}>+ Nova Anotação</Text>

        <TextInput
          placeholder="Valor"
          placeholderTextColor="#fff"
          style={styles.inputAnotacao}
          value={valor}
          onChangeText={setValor}
          keyboardType="numeric"
        />

        <View style={{ flexDirection: 'row', justifyContent: 'center', marginBottom: 10 }}>
          <TouchableOpacity
            style={[styles.tipoBtn, tipo === 'gasto' && styles.tipoBtnSelected]}
            onPress={() => setTipo('gasto')}
          >
            <Text style={tipo === 'gasto' ? styles.tipoTextoSelecionado : styles.tipoTexto}>💸 Gasto</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tipoBtn, tipo === 'poupanca' && styles.tipoBtnSelected]}
            onPress={() => setTipo('poupanca')}
          >
            <Text style={tipo === 'poupanca' ? styles.tipoTextoSelecionado : styles.tipoTexto}>💲 Poupança</Text>
          </TouchableOpacity>
        </View>

        <TextInput
          placeholder="Data"
          placeholderTextColor="#fff"
          style={styles.inputAnotacao}
          value={data}
          onChangeText={setData}
        />

        <TouchableOpacity style={styles.btn} onPress={() => alert('Registrado!')}>
          <Text style={styles.btnText}>Registrar</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="NovaAnotacao" component={NovaAnotacaoScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.3)', 
    zIndex: 1,
  },
  logoImage: {
    width: screenWidth * 0.8,
    height: screenWidth * 0.8,
    marginBottom: 20,
    zIndex: 2,
  },
  logoImageSmall: {
    width: screenWidth * 0.6,
    height: screenWidth * 0.6,
    marginBottom: 20,
    zIndex: 2,
  },
  loginBox: {
    width: '80%',
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 10,
    padding: 20,
    zIndex: 2,
  },
  loginTitle: {
    color: '#fff',
    fontSize: 24,
    fontWeight: '300',
    fontFamily: 'System',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    backgroundColor: '#eee',
    marginBottom: 15,
    borderRadius: 20,
    paddingHorizontal: 20,
    height: 40,
    color: '#000',
    fontFamily: 'System',
    fontWeight: '300',
  },
  btn: {
    backgroundColor: '#000',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 50,
    alignItems: 'center',
  },
  btnText: {
    color: '#fff',
    fontWeight: '300',
    fontFamily: 'System',
  },
  novaAnotacaoContent: {
    padding: 20,
    alignItems: 'center',
    width: '100%',
  },
  novaAnotacaoTitulo: {
    color: '#fff',
    marginBottom: 10,
    fontSize: 20,
    fontWeight: '300',
    fontFamily: 'System',
  },
  inputAnotacao: {
    backgroundColor: '#444',
    width: '80%',
    borderRadius: 20,
    paddingHorizontal: 20,
    marginBottom: 10,
    height: 40,
    color: '#fff',
    fontFamily: 'System',
    fontWeight: '300',
  },
  tipoBtn: {
    backgroundColor: '#000',
    marginHorizontal: 10,
    borderRadius: 20,
    paddingHorizontal: 15,
    paddingVertical: 8,
  },
  tipoBtnSelected: {
    backgroundColor: '#eee',
  },
  tipoTexto: {
    color: '#fff',
    fontFamily: 'System',
    fontWeight: '300',
  },
  tipoTextoSelecionado: {
    color: '#000',
    fontWeight: '300',
    fontFamily: 'System',
  },
});
